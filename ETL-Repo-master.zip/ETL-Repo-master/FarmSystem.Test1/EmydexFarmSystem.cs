﻿using System;
using System.Collections.Generic;

namespace FarmSystem.Test1
{

    public class EmydexFarmSystem
    {

        public event EventHandler ReleasedAllAnimals;

        List<Animal> animals = new List<Animal>();
        

        //TEST 1
        public void Enter(object animal)
        {
            //TODO Modify the code so that we can display the type of animal (cow, sheep etc) 
            //Hold all the animals so it is available for future activities
            Animal objAnimal;
            try
            {
                if (animal is Animal)
                {
                    objAnimal = (Animal)animal;
                    animals.Add(objAnimal); //add animal to the list
                    Console.WriteLine(objAnimal.Id + " has entered the farm");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while animals entering farm: " + ex.Message);
            }
        }
     
        //TEST 2
        public void MakeNoise()
        {
            //Test 2 : Modify this method to make the animals talk
            try
            {
                foreach (Animal obj in animals)
                {
                    obj.Talk();
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine("Error while animal talk : " + ex.Message);
            }
        }

        //TEST 3
        public void MilkAnimals()
        {
            try
            {
                foreach (Animal obj in animals)
                {
                    if(obj is Cow)
                    {
                        Cow cow = (Cow)obj; //cast Animal obj into Cow to call Cow specific function
                        cow.ProduceMilk();
                    }
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine("Error while Milking animals: " + ex.Message);
            }
            
        }

        //TEST 4
        public void ReleaseAllAnimals()
        {

            try
            {

                for (int i = animals.Count - 1; i >= 0; i--)
                {

                    Console.WriteLine(animals[i].Id + " has left the farm");
                    animals.RemoveAt(i); //remove animal from the list once the animal is released
                }

                //Invoke event if all animals are released
                if (animals.Count <= 0)
                {
                    OnReleasedAllAnimals(EventArgs.Empty);
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error while Releasing Animals: " + ex.Message);
            }
        }

        protected virtual void OnReleasedAllAnimals(EventArgs e)
        {
            ReleasedAllAnimals?.Invoke(this,e);
        }
    }
}